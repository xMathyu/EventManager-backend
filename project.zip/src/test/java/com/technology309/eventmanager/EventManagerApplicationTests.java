package com.technology309.eventmanager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EventManagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
